<template>
  <div class="main-container">
    <div class="header">
      <v-btn @click="signOut">Sign Out</v-btn>
      <v-btn @click="toggleRepairs">{{ showRepairs ? 'Hide Repairs' : 'Show Repairs' }}</v-btn>
    </div>
    <div class="content">
      <RepairsTable
        :repairs="repairs"
        :columnHeaders="columnHeaders"
        :showTable="showRepairs"
      />
    </div>
  </div>
</template>

<script>
import { getAuth, signOut } from 'firebase/auth';
import { getFirestore, collection, onSnapshot } from 'firebase/firestore';
import RepairsTable from './RepairsTable.vue';

export default {
  name: 'MainPage',
  components: {
    RepairsTable
  },
  data() {
    return {
      repairs: [],
      columnHeaders: {},
      showRepairs: false
    }
  },
  created() {
    const auth = getAuth();
    const db = getFirestore();
    const repairsCollection = collection(db, 'Repairs');

    // Listen for authentication state changes
    auth.onAuthStateChanged(user => {
      if (user) {
        // User is signed in
        this.fetchRepairs(repairsCollection);
      } else {
        // User is signed out
        this.repairs = [];
        this.columnHeaders = {};
        this.showRepairs = false;
      }
    });
  },
  methods: {
    signOut() {
      const auth = getAuth();
      signOut(auth)
        .then(() => {
          this.$router.push('/');
        })
        .catch(error => {
          console.error('Error signing out:', error);
        });
    },
    fetchRepairs(repairsCollection) {
      onSnapshot(repairsCollection, querySnapshot => {
        this.repairs = querySnapshot.docs.map(doc => ({
          id: doc.id,
          data: doc.data()
        }));

        // Get unique column headers from the first document
        if (querySnapshot.docs.length > 0) {
          this.columnHeaders = querySnapshot.docs[0].data();
        }
      });
    },
    toggleRepairs() {
      this.showRepairs = !this.showRepairs;
    }
  }
}
</script>

<style>
.main-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 20px;
}

.header {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 20px;
}

.content {
  flex: 1;
}
</style>